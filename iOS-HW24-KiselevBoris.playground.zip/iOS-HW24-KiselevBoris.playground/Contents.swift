import Foundation
import CommonCrypto
import CryptoKit

struct Card: Decodable {
    let name: String?
    let manaCost: String?
    let cmc: Int?
    let type: String?
    let rarity: String?
    let id: String?
}

struct Cards: Decodable {
    let cards: [Card]
}

func makeUrlSessionWithTimeout(_ timeout: TimeInterval) -> URLSession {
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    configuration.waitsForConnectivity = true
    configuration.timeoutIntervalForRequest = timeout
    configuration.httpMaximumConnectionsPerHost = 100
    configuration.urlCache = URLCache()
    
    return URLSession(configuration: configuration)
}

let blackLotusUrl = "https://api.magicthegathering.io/v1/cards?name=Black%20Lotus"
let optUrl = "https://api.magicthegathering.io/v1/cards?name=Opt"

let urlSession = makeUrlSessionWithTimeout(20)

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    guard let url = urlRequest else { return }
    urlSession.dataTask(with: url) { data, response, error in
        if error != nil {
            
        } else  if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print(response.statusCode)
            guard let data = data else { return }
            do {
                let jsonEn = try JSONDecoder().decode(Cards.self, from: data)
                jsonEn.cards.map { print("""
                   Имя карты: \($0.name ?? "Has no name")
                   Мановая стоимость: \($0.manaCost ?? "Has no mana cost")
                   СМС: \($0.cmc ?? 0)
                   Тип: \($0.type ?? "Has no type")
                   Раритетность: \($0.rarity ?? "Has no rarity")
                   ID: \($0.id ?? "Has no id")
                   ----------------------------------------
                """)}
            } catch let error {
                print(error)
            }
        } else  if let response = response as? HTTPURLResponse, response.statusCode != 200 {
            print("Erorr \(response.statusCode)")
        }
    }.resume()
}

getData(urlRequest: blackLotusUrl)
getData(urlRequest: optUrl)

